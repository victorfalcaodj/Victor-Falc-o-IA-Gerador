
import React from 'react';

interface FunctionCardProps {
  icon: string;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const FunctionCard: React.FC<FunctionCardProps> = ({ icon, label, isActive, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`p-4 bg-gray-700 rounded-lg text-center cursor-pointer transition-all duration-200 transform hover:-translate-y-1 hover:shadow-lg ${
        isActive ? 'ring-2 ring-blue-500 bg-gray-600' : 'ring-1 ring-transparent'
      }`}
    >
      <div className="text-3xl">{icon}</div>
      <div className="mt-2 font-semibold text-sm text-gray-200">{label}</div>
    </div>
  );
};

export default FunctionCard;
