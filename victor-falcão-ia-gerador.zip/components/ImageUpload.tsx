
import React from 'react';
import type { ImageData } from '../types';

interface ImageUploadProps {
  id: string;
  title: string;
  imageData: ImageData | null;
  setImageData: (data: ImageData | null) => void;
}

const fileToImageData = (file: File): Promise<ImageData> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        if (base64) {
            resolve({
                base64,
                mimeType: file.type,
                name: file.name
            });
        } else {
            reject(new Error("Failed to read file as base64"));
        }
    };
    reader.onerror = (error) => reject(error);
  });


const ImageUpload: React.FC<ImageUploadProps> = ({ id, title, imageData, setImageData }) => {
  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const data = await fileToImageData(file);
        setImageData(data);
      } catch (error) {
        console.error("Error processing file:", error);
        setImageData(null);
      }
    }
  };
  
  const handleRemoveImage = (e: React.MouseEvent<HTMLButtonElement>) => {
      e.stopPropagation();
      setImageData(null);
  }

  return (
    <div>
        <input
            type="file"
            id={id}
            accept="image/*"
            onChange={handleFileChange}
            style={{ display: 'none' }}
        />
        <label htmlFor={id} className="cursor-pointer">
            <div className="relative w-full h-32 bg-gray-700 border-2 border-dashed border-gray-600 rounded-lg flex flex-col items-center justify-center text-center hover:bg-gray-600 hover:border-blue-500 transition-all">
                {imageData ? (
                    <>
                        <img src={`data:${imageData.mimeType};base64,${imageData.base64}`} alt="Preview" className="absolute inset-0 w-full h-full object-cover rounded-lg" />
                        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                            <span className="text-white font-bold">Trocar Imagem</span>
                        </div>
                        <button onClick={handleRemoveImage} className="absolute top-1 right-1 bg-red-600 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs font-bold z-10 hover:bg-red-700">&times;</button>
                    </>
                ) : (
                    <>
                        <div className="text-3xl text-gray-500">📁</div>
                        <div className="font-semibold text-gray-300 mt-1">{title}</div>
                        <div className="text-xs text-gray-400">Clique para selecionar</div>
                    </>
                )}
            </div>
        </label>
    </div>
  );
};

export default ImageUpload;
