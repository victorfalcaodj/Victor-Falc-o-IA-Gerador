
import React from 'react';
import type { Mode, CreateFunction, EditFunction, ImageData } from '../types';
import FunctionCard from './FunctionCard';
import ImageUpload from './ImageUpload';

interface LeftPanelProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  mode: Mode;
  setMode: (mode: Mode) => void;
  createFunction: CreateFunction;
  setCreateFunction: (func: CreateFunction) => void;
  editFunction: EditFunction;
  setEditFunction: (func: EditFunction) => void;
  image1: ImageData | null;
  setImage1: (image: ImageData | null) => void;
  image2: ImageData | null;
  setImage2: (image: ImageData | null) => void;
}

const LeftPanel: React.FC<LeftPanelProps> = ({
  prompt,
  setPrompt,
  mode,
  setMode,
  createFunction,
  setCreateFunction,
  editFunction,
  setEditFunction,
  image1,
  setImage1,
  image2,
  setImage2
}) => {
    
  const createFunctions: { key: CreateFunction; icon: string; label: string }[] = [
    { key: 'free', icon: '✨', label: 'Prompt' },
    { key: 'sticker', icon: '🏷️', label: 'Adesivos' },
    { key: 'text', icon: '📝', label: 'Logo' },
    { key: 'comic', icon: '💭', label: 'HQ' },
  ];

  const editFunctions: { key: EditFunction; icon: string; label: string, requiresTwo?: boolean }[] = [
    { key: 'add-remove', icon: '➕', label: 'Adicionar' },
    { key: 'retouch', icon: '🎯', label: 'Retoque' },
    { key: 'style', icon: '🎨', label: 'Estilo' },
    { key: 'compose', icon: '🖼️', label: 'Unir', requiresTwo: true },
  ];

  const showImageUpload = mode === 'edit';
  const showTwoImages = mode === 'edit' && editFunction === 'compose';


  return (
    <div className="w-full md:w-1/3 lg:w-1/4 bg-gray-800 p-6 flex flex-col space-y-6 overflow-y-auto">
      <div className="flex-shrink-0">
        <h1 className="text-2xl font-bold text-blue-400">🎨 Victor Falcão IA Gerador</h1>
        <p className="text-gray-400 mt-1">Gerador moderno e simples de imagens com IA</p>
      </div>

      <div className="flex-grow flex flex-col space-y-6">
        <div>
          <label className="text-lg font-semibold text-gray-300">💭 Descreva sua ideia</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-28 mt-2 p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:outline-none transition"
            placeholder="Ex: Cena futurista, DJ Victor Falcão no palco, luzes neon e multidão"
          />
        </div>

        <div className="flex bg-gray-700 rounded-lg p-1">
          <button
            onClick={() => setMode('create')}
            className={`w-1/2 py-2 rounded-md text-center font-semibold transition ${mode === 'create' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-600'}`}
          >
            Criar
          </button>
          <button
            onClick={() => setMode('edit')}
            className={`w-1/2 py-2 rounded-md text-center font-semibold transition ${mode === 'edit' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-600'}`}
          >
            Editar
          </button>
        </div>

        {mode === 'create' && (
          <div className="grid grid-cols-2 gap-3">
            {createFunctions.map((func) => (
              <FunctionCard
                key={func.key}
                icon={func.icon}
                label={func.label}
                isActive={createFunction === func.key}
                onClick={() => setCreateFunction(func.key)}
              />
            ))}
          </div>
        )}

        {mode === 'edit' && (
          <div className="grid grid-cols-2 gap-3">
            {editFunctions.map((func) => (
              <FunctionCard
                key={func.key}
                icon={func.icon}
                label={func.label}
                isActive={editFunction === func.key}
                onClick={() => setEditFunction(func.key)}
              />
            ))}
          </div>
        )}

        {showImageUpload && (
            <div className={`transition-all duration-300 ease-in-out ${showImageUpload ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0'}`}>
                {showTwoImages ? (
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-300">📸 Duas Imagens Necessárias</h3>
                        <ImageUpload
                            id="imageUpload1"
                            title="Primeira Imagem"
                            imageData={image1}
                            setImageData={setImage1}
                        />
                        <ImageUpload
                            id="imageUpload2"
                            title="Segunda Imagem"
                            imageData={image2}
                            setImageData={setImage2}
                        />
                    </div>
                ) : (
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-300">📸 Imagem para Editar</h3>
                        <ImageUpload
                            id="imageUpload1"
                            title="Sua Imagem"
                            imageData={image1}
                            setImageData={setImage1}
                        />
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default LeftPanel;
