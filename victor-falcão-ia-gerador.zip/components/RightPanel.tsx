
import React from 'react';

interface RightPanelProps {
  generatedImage: string | null;
  isLoading: boolean;
  error: string | null;
  onGenerate: () => void;
}

const LoadingSpinner: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center">
      <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mb-4"></div>
      <p className="text-lg font-semibold text-gray-300">Gerando sua obra de arte...</p>
      <p className="text-gray-400">A IA está pensando, isso pode levar um momento.</p>
    </div>
);

const InitialState: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center text-gray-500">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <h2 className="text-2xl font-bold text-gray-400">Sua imagem aparecerá aqui</h2>
        <p className="mt-2">Preencha os detalhes à esquerda e clique em "Gerar".</p>
    </div>
);


const RightPanel: React.FC<RightPanelProps> = ({
  generatedImage,
  isLoading,
  error,
  onGenerate,
}) => {
  return (
    <div className="w-full md:w-2/3 lg:w-3/4 bg-gray-900 p-6 flex flex-col">
      <div className="flex-grow flex items-center justify-center bg-black bg-opacity-20 rounded-xl border-2 border-dashed border-gray-700">
        {isLoading ? (
          <LoadingSpinner />
        ) : error ? (
          <div className="text-center text-red-400 bg-red-900 bg-opacity-50 p-6 rounded-lg">
             <h3 className="text-xl font-bold mb-2">Ops! Algo deu errado.</h3>
             <p>{error}</p>
          </div>
        ) : generatedImage ? (
          <img src={generatedImage} alt="Generated Art" className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"/>
        ) : (
          <InitialState />
        )}
      </div>
      <div className="flex-shrink-0 mt-6">
        <button
          onClick={onGenerate}
          disabled={isLoading}
          className="w-full bg-blue-600 text-white font-bold py-4 px-6 rounded-lg text-xl hover:bg-blue-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100 flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white"></div>
              <span>Gerando...</span>
            </>
          ) : (
             <span>🚀 Gerar Imagem</span>
          )}
        </button>
      </div>
    </div>
  );
};

export default RightPanel;
