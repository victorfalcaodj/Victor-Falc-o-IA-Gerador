
import { GoogleGenAI, Modality, Part } from "@google/genai";
import type { Mode, CreateFunction, EditFunction, ImageData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });

interface GenerateParams {
  prompt: string;
  mode: Mode;
  createFunction: CreateFunction;
  editFunction: EditFunction;
  image1: ImageData | null;
  image2: ImageData | null;
}

const getFullPrompt = (prompt: string, func: CreateFunction): string => {
    switch(func) {
        case 'sticker':
            return `Design a high-quality sticker of: ${prompt}. The sticker should have a distinct die-cut border and a clean, vibrant aesthetic suitable for printing.`;
        case 'text':
            return `Create a typographic logo with the text "${prompt}". The style should be modern, clean, and professional. Provide the logo on a plain background.`;
        case 'comic':
            return `Illustrate a single comic book panel for the following scene: ${prompt}. The style should be reminiscent of classic American comics, with bold lines, dynamic action, and dot shading.`;
        case 'free':
        default:
            return prompt;
    }
}


export const generateContent = async ({
  prompt,
  mode,
  createFunction,
  editFunction,
  image1,
  image2,
}: GenerateParams): Promise<string> => {
    if (mode === 'create') {
        const fullPrompt = getFullPrompt(prompt, createFunction);
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: fullPrompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/png',
              aspectRatio: '1:1',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return `data:image/png;base64,${base64ImageBytes}`;
        } else {
            throw new Error("A geração de imagens não retornou nenhum resultado.");
        }
    } else { // edit mode
        if (!image1) {
            throw new Error("É necessária uma imagem para o modo de edição.");
        }

        const parts: Part[] = [
            { inlineData: { data: image1.base64, mimeType: image1.mimeType } }
        ];

        if (editFunction === 'compose' && image2) {
            parts.push({ inlineData: { data: image2.base64, mimeType: image2.mimeType } });
        }
        
        parts.push({text: prompt});

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: { parts: parts },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:image/png;base64,${part.inlineData.mimeType}`;
            }
        }
        
        throw new Error("A edição de imagem não retornou um resultado de imagem.");
    }
};
